"""The offline pipeline orchestrator + CLI (ADR-0057). Runs the named stages per case, applies CONTRACT 1,
writes the compact artifact + manifest (CONTRACT 2) and a flat index.json.

    python -m chronoscopelab.pipeline                 # all cases
    python -m chronoscopelab.pipeline SEAS_hourly --seed 7
"""
from __future__ import annotations

import argparse
import os
import time
from pathlib import Path

from . import registry
from .core.manifest import build_index
from .io.contract import validate_series
from .io.formats import write_json
from .model.forecasters import forecast_all
from .stages import analyze, evaluate, export, feature_extraction, infer, streaming, train

# data-pipeline/chronoscopelab/pipeline.py -> parents[2] = repo root (works under `pip install -e .` too)
REPO_ROOT = Path(__file__).resolve().parents[2]
# CHRONOSCOPE_DERIVED_DIR redirects the output tree (tests, CI smoke). The committed data/derived is the
# CANONICAL GPU bake (all 19 methods incl. the TiRex-2 WSL lane); anything that regenerates on a lighter
# engine set must write elsewhere, or it silently downgrades the artifacts the site deploys (this
# happened: a pytest run_all clobbered the then-18-method bake to the 9-method CPU lane and it shipped).
DERIVED = Path(os.environ.get("CHRONOSCOPE_DERIVED_DIR", REPO_ROOT / "data" / "derived"))
MANIFESTS = DERIVED / "manifests"
MODELS = REPO_ROOT / "models"

STAGES = ("preprocess", "analyze", "feature_extraction", "train", "infer", "evaluate", "export")
QUANTILE_LEVELS = (0.1, 0.5, 0.9)


def _train_selector(seed: int) -> dict:
    # Learn the global method ranking from the SYNTHETIC training cases only (leakage-safe: real cases
    # are scored on their own held-out windows, never used to pick the global default).
    specs = [registry.build_series(c, seed=seed) for c in registry.list_cases()
             if c.real_or_synthetic == "synthetic"]
    return train.run(specs, str(MODELS), QUANTILE_LEVELS)


def precompute(case_id: str, seed: int = 42, selector: dict | None = None) -> dict:
    case = registry.get_case(case_id)
    if selector is None:
        selector = _train_selector(seed)
    spec = registry.build_series(case, seed=seed)

    # CONTRACT 1 on the produced series (proves the gate + carries flags); BYO data enters the same way.
    ds = [str(i) for i in range(len(spec.y))]
    _rec, _rej, flag = validate_series(spec.case_id, ds, list(spec.y))
    flags = [flag] if flag else []

    # The "understand the series" panel (10 diagnostic families) baked alongside the forecast trace.
    analysis = analyze.run(spec, seed=seed)

    # The streaming bench (preqts, the flagship novel piece): prequential skill/coverage/cost trajectories
    # for the raw vs ACI- vs PID-calibrated methods; the web streaming bench renders these.
    streaming_bench = streaming.run(spec)

    feature = feature_extraction.run(spec)
    result = infer.run(spec, QUANTILE_LEVELS)
    history, actual = infer.split(spec)
    eval_metrics = evaluate.run(spec, QUANTILE_LEVELS)

    # opt-in cross-OS foundation method: TiRex-2 via the WSL2 lane (needs flashrnn/triton, no Windows
    # wheels). Merges as the 19th method when CHRONOSCOPE_ENABLE_TIREX_WSL=1 and WSL is reachable; a no-op
    # otherwise, so CI and the default bake are unaffected. See engines/tirex2_wsl_engine.py.
    from .engines import tirex2_wsl_engine
    result, eval_metrics = tirex2_wsl_engine.merge_into(result, eval_metrics, spec, QUANTILE_LEVELS)

    # The gate's run_ms measures the LIVE-lane (classical, browser) path, not the offline heavy engines
    # (statsforecast) that never run live. This keeps the live/precompute verdict honest.
    t_live = time.perf_counter()
    forecast_all(history, spec.seasonality, spec.horizon, QUANTILE_LEVELS)
    run_ms = (time.perf_counter() - t_live) * 1000.0

    return export.run(
        case=case, feature=feature, result=result, actual=[float(v) for v in actual],
        eval_metrics=eval_metrics, seed=seed, run_ms=run_ms, flags=flags,
        derived_dir=str(DERIVED), manifests_dir=str(MANIFESTS), analysis=analysis,
        streaming_bench=streaming_bench,
    )


def run_all(seed: int = 42) -> list[dict]:
    selector = _train_selector(seed)
    entries = []
    for c in registry.list_cases():
        precompute(c.id, seed=seed, selector=selector)
        entries.append({"case_id": c.id, "category": c.category, "manifest_path": f"manifests/{c.id}.json"})
    write_json(MANIFESTS / "index.json", build_index(entries))
    return entries


def main() -> None:
    ap = argparse.ArgumentParser(prog="chronoscopelab.pipeline")
    ap.add_argument("case", nargs="?", default="all", help="a case id, or 'all'")
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()
    from . import gpu
    print(gpu.summary())  # record the compute device used for this bake
    if args.case == "all":
        entries = run_all(args.seed)
        print(f"precomputed {len(entries)} cases -> {DERIVED}")
        for e in entries:
            print(f"  {e['case_id']:20s} [{e['category']}]")
        print(f"index -> {MANIFESTS / 'index.json'}")
    else:
        m = precompute(args.case, args.seed)
        print(f"precomputed {args.case}: lane={m['lane']} bytes={m['artifact']['bytes']} "
              f"best={m['best_method']} best_mase={m['metrics']['best_mase']} "
              f"-> {DERIVED / m['artifact']['path']}")


if __name__ == "__main__":
    main()
