"""The case registry: cases grouped by CATEGORY. The App shows ONE selected case; Experiments/Benchmark
show cross-case summaries by category."""
from __future__ import annotations

from .cases.forecast_cases import CASES, Case, build_series

_BY_ID: dict[str, Case] = {c.id: c for c in CASES}


def list_cases() -> list[Case]:
    return list(CASES)


def get_case(case_id: str) -> Case:
    if case_id not in _BY_ID:
        raise KeyError(f"unknown case: {case_id!r}. known: {sorted(_BY_ID)}")
    return _BY_ID[case_id]


def list_categories() -> dict[str, list[str]]:
    out: dict[str, list[str]] = {}
    for c in CASES:
        out.setdefault(c.category, []).append(c.id)
    return out


__all__ = ["CASES", "Case", "build_series", "list_cases", "get_case", "list_categories"]
